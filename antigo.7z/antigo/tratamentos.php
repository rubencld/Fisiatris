<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="pt"> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang="pt"> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang="pt"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="pt"> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

	<title>Fisiatris - Recuperação Física, Lda - Tratamentos</title>
	<meta name="description" content="Tratamentos dísponiveis na Fisiatris ,Clínica de Fisioterapia e Recuperação Física em Sacavém">
	<meta name="author" content="">

	<meta name="viewport" content="width=device-width">

	<link rel="stylesheet" href="css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Nunito:400,700' rel='stylesheet' type='text/css'>
    <link href='assets/favicon.ico' rel="shortcut icon" type="image/x-icon">
	<script src="js/libs/modernizr-2.5.2.min.js"></script>
      <link rel="stylesheet" type="text/css" href="css/rhinoslider-1.03.css">
    
</head>
<body>
<header>
	<img src="assets/fisisatris_logotipo.png" width="283" height="105" alt="Logotipo Fisiatris">
    
    <ul id="menu">
        <li><a href="index.php">Home</a></li>
        <li><a href="sobre.php">Sobre Nós</a></li>
        <li><a href="tratamentos.php">Tratamentos</a></li>
        <li><a href="acordos.php">Acordos</a></li>
        <li><a href="contactos.php">Localização &amp; Contactos</a></li>
    </ul><!--/menu-->
</header>

<div id="main">
      
	<ul id="tratamentos_galeria">
    
               
        <li>
            <h3 style=" float:left; display:inline-block;" class="caixa_titulo">Ondas de Choque</h3>
            <p>
            É um tratamento que aplica-se em Patologias como : Tendinites no Rotuliano , Epicondilites , Calcificações da art do Ombro , Tendinites no tendão de Aquiles e esporões Calcâneos como fasceites plantares .</p>	
            <img src="assets/tratamentos/ondas.jpg" width="350" height="215">
        </li>
        
        <li>
            <h3 style=" float:left; display:inline-block;" class="caixa_titulo">Mesoterapia</h3>
            
            <p>
            Aplicação de medicamentos através de micropicadas intra-dermicas de tal modo que a sua acção se faça directa e exclusivamente na(s) zona(s) a tratar, 
            aumentando a sua eficácia e rapidez de actuação e reduzindo assim ao mínimo potenciais efeitos secundários.</p>	
            <img src="assets/tratamentos/mesoterapia.jpg" width="350" height="215">
        </li>
    
 </ul>
    
    
</div>
<div style="height:505px;" id="main2" class="caixa">
  
    <h3 class="caixa_titulo" style="margin-bottom:10px;">Especialidades</h3>
       
        
	<div id="main2_servicos" style="height:390px;">
         <ul style="width:55%;">
           
          
            <li>Artroses</li>
            <li>Ciátalgias</li>
             <li>Cinesioterapia Respiratória</li>
             
         
            <li>Drenagem Linfática</li>
            <li>Electroterapia</li>
            <li>Entorses</li>
            <li>Ginástica Postural (Preventiva e Correctiva)</li>
            <li>Laserterapia</li>
            <li>Ligamentoplastias </li>
            
            
           
        </ul>
        <ul style="width:45%">
         
          <li>Magnetoterapia</li>
           
            <li>Massagem</li>
            <li>Medicina Desportiva</li>
            <li>Meniscectomia</li>
            <li>Mesoterapia</li>
            <li>Ondas de Choque</li>
            
            <li>Pressoterapia</li>
            <li>Próteses (Anca, joelhos)</li>
            
            
            <li>Tendinites</li>
            
       
        </ul>
	</div><!--/main2_servicos-->


</div>



    	

<h3 class="caixa_lateral_titulo">Contactos<img style="top:-12px; left:30px;" src="assets/icon_telefone.png" width="47" height="46" alt="Imagem Telefone"></h3>
<div class="caixa_lateral">Tel: 21 940 84 17/ 18 <br>&nbsp;21 941 07 64  <span style="margin-top:8px; display:block;">Fax:&nbsp;21 940 84 36</span></div> 

<h3 class="caixa_lateral_titulo">Horário<img style="top:-12px; left:30px;" src="assets/icon_relogio.png" width="45" height="45" alt="Imagem Relógio"></h3>
<div class="caixa_lateral">De Segunda a Sexta<br> das 8:00h às 20:00h   </div> 

<h3 class="caixa_lateral_titulo">Acordos<img style="top:-12px; left:30px;" src="assets/icon_acordos.png" width="45" height="45" alt="Imagem Acordos"></h3>
<div class="caixa_lateral"><img src="assets/acordos.jpg"  alt="ADSE Medicare Médis"> <a href="acordos.php">Consultar todos os acordos dísponiveis.</a> </div> 


</div>

<footer><span style="float:left;">&copy; 2012 Fisiatris | Rua Sport Grupo Sacavenense, Nº22 - A Quinta do Património -2685-010 Sacavém</span>
<a href="http://www.rubencaldeira.pt">Desenvolvido por: RC Web Design</a>
</footer>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/libs/jquery-1.7.1.min.js"><\/script>')</script>




<script type="text/javascript" src="js/rhinoslider-1.03.js"></script>
<script type="text/javascript" src="js/mousewheel.js"></script>
<script>

$(document).ready(function() {
	$('#tratamentos_galeria').rhinoslider({
		effect: 'fade',
		easing: 'linear',
		showTime: 3000,
		effectTime: 500,
	
		animateActive:true,
		autoPlay: true,
		showBullets: 'never',
		showControls: 'never'
	});
});
</script>
<!--[if lt IE 9]>
<script type="text/javascript" src="js/curvycorners.js"></script>
<![endif]-->

<script src="js/plugins.js"></script>
<script src="js/script.js"></script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-16636359-5']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
</body>
</html>
